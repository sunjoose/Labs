<?php include "lib/header.php"; ?>
<?php
//////////////This page is Grant's, with my only alteration being the div class center, which I wrote into my CSS file. Other than that, I see no improvements to be made here, so I left the file as it was.
 ?>
<!DOCTYPE HTML>
<html>
	<body>
		<main id="mapMain">
			<h3>Visit Us Today!</h3>
			<?php /* Embedded map */ ?>
      <div class="center">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6863.851985452717!2d-96.35565987436881!3d30.664212426644493!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8646816ef04a3999%3A0xe8202b189287bbd2!2sBlinn+College-Bryan+Campus%2C+Bryan%2C+TX+77802!5e0!3m2!1sen!2sus!4v1509056470633" width="600" height="450" frameborder="0" style="border:0" allowfullscreen id="map"></iframe>
      </div>
		</main>
	</body>
</html>

<?php include "lib/footer.php"; ?>

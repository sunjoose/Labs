<!DOCTYPE HTML>
<html>
	<footer>
		<p>
			<i>BTG</i> Auto Shop<br/>
			<a href="mailto:SendEverythingToCaitlinGrant@WheelyBadJokes.com">Email Us</a><br/>
			Store Hours:<br/>
			Mon - Sat: 10 AM to 9 PM<br/>
			Sunday: 8 AM to 7 PM
		</p>
	</footer>
  <script>
  var footerResize = function() {
    $('#footer').css('position', $("body").height() + $("#footer").innerHeight() > $(window).height() ? "inherit" : "fixed");
  };
  $(window).resize(footerResize).ready(footerResize);
</script>
</html>

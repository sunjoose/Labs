<!DOCTYPE HTML>
<html>
	<head>
		<title>Lab 05</title>
		<link href="lib\styles.css" rel="stylesheet" type="text/css" />
    <div class="header">
      <img src="images/logo.png" height="150px" />
    </div>
		<?php /* Main navigation bar */ ?>
		<nav id="mainNav">
			<a href="index.php">Home</a>
			<a href="products.php">Products</a>
			<a href="sales.php">Sales</a>
			<a href="geomap.php">Map</a>
		</nav>
	</head>
</html>

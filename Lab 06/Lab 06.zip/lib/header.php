<!DOCTYPE HTML>
<html>
	<head>
		<title>Lab 06</title>
		<link href="lib/styles.css" rel="stylesheet" type="text/css" />
    <div class="header">
      <h1>STANLEY KUBRICK FAKED THE MOON LANDING</h1>
    </div>
		<?php /* Main navigation bar */ ?>
		<nav id="mainNav">
			<a href="index.php">Home</a>
		</nav>
	</head>
</html>

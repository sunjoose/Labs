<!DOCTYPE HTML>
<link href="lib/styles.css" rel="stylesheet" type="text/css" />

<html>
  <div name="rightcol" class="rightcol">
    <p style="text-align: center;">
      <img src="images/blinkerfluid2.jpg" alt="Buy now!">
    </p>
  </div>
</html>

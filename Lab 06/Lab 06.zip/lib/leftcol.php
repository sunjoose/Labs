<!DOCTYPE HTML>
<link href="lib/styles.css" rel="stylesheet" type="text/css" />

<html>
  <div name="leftcol" class="leftcol">
    <p><a href="index.php">Home</a></p>
  </div>
</html>
